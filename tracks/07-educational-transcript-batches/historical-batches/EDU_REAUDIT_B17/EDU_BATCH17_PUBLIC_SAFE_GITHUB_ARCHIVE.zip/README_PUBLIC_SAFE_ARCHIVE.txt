EDU BATCH 17 — PUBLIC-SAFE GITHUB ARCHIVE
Date 2026-10-24

Contains six publication-safe research documents already publicly committed to GitHub. These are original analyst summaries, short paraphrases, research/QA metadata, source hashes and progress records.

IMPORTANT: NOT THE FULL ORIGINAL BATCH 17 RESEARCH PACKAGE. The original 637,651-byte ZIP, full 1,030-claim corpus, verbatim source anchors, historical B16 original package, and original third-party transcripts are not included because their public redistribution rights are not confirmed.

Claim IDs EDU-C1020–EDU-C1030 are provisional. QA EDU-C0018–EDU-C0030 is text-source-only. No causal retention proof or production SKILL.md approval.

Source: https://github.com/crimestory5694-beep/universal-scriptwriting-research-hub/tree/main/tracks/07-educational-transcript-batches/historical-batches/EDU_REAUDIT_B17
