# Batch 7 research publication rights gate

PUBLIC: only original researcher-authored report and aggregate integrity JSON. No original third-party captions, restricted individual cases or private archive lineage. An inherited B06 manifest self-hash mismatch was retained; original archive unchanged. All claimed retention benefits untested. SKILL.md HOLD.
