# S3 PUBLIC rights and science gate

Researcher-authored aggregates, URLs and K/F/R references only. Private educational source-qualified keys, individual transcript paraphrases, third-party protected full source texts, 31MB nested predecessor and 48 restricted case decisions are NOT publicly transferred. The 2014 ACM paper PDF is not redistributed. Source R052 still blocked; historical archive anomalies, source AV, and T01–T13 controlled studies remain open. Research-only; zero SKILL.md permissions.
