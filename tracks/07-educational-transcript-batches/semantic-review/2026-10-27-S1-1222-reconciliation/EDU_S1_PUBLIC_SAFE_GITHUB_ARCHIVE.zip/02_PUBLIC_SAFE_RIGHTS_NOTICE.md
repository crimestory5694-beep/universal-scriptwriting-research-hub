# PUBLIC rights and scientific scope — S1

This release includes only original research-director aggregate reasoning, counters and source registry identity references. PRIVATE 1,222-key individual observations, protected source paraphrases and exact original nested 31 MB archives are withheld. Source-text editorial review does not establish native audio/video authenticity, scientific retention benefit, or redistribution rights. Missing B70–B72 exact bytes and other archival holds persist. No production rule approval or SKILL.md implementation authorized.
