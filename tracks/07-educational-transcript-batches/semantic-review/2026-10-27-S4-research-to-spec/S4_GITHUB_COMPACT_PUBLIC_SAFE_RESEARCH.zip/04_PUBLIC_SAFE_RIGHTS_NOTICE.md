# S4 rights boundary

Publicly published only original research notes, pre-existing nonconfidential K labels and proposed decision summaries. Private EDU case keys, complete third-party source texts, restricted source-specific paraphrases, full private S3/S4 nested continuity ZIPs, credentials and personal material were withheld. No production skill approval; no empirical uplift shown. Local full public-safe ZIP and GitHub compact publication are distinct binaries.
